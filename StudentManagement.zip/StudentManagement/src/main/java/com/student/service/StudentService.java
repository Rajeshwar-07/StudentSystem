package com.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.entity.Student;
import com.student.repository.StudentRepo;

@Service
public class StudentService {

	@Autowired
	private StudentRepo studentRepo;

	public Student createRecord(Student student) {
		return studentRepo.save(student);
	}

	public Student getRecordById(int id) {
		return studentRepo.findById(id).get();
	}

	public List<Student> getAllRecord() {
		return studentRepo.findAll();
	}

	public String deleteRecord(int id) {
		studentRepo.deleteById(id);
		return "Record Deleted successfully";
	}

	public Student updateRecord(Student newStudent, int id) {
		Student student = studentRepo.findById(id).get();
		student.setName(newStudent.getName());
		student.setPhone(newStudent.getPhone());
		student.setAddress(newStudent.getAddress());
		student.setCourse(newStudent.getCourse());

		return studentRepo.save(student);

	}

}
