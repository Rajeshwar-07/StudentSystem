package com.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.entity.Student;
import com.student.service.StudentService;

@RestController
@RequestMapping("/rest/stu/api")
public class StudentController {

	@Autowired
	private StudentService studentService;

	@PostMapping("/saveRecord")
	public Student saveRecord(@RequestBody Student student) {
		return studentService.createRecord(student);
	}

	@GetMapping("/record/{id}")
	public Student getRecordById(@PathVariable int id) {
		return studentService.getRecordById(id);
	}

	@GetMapping("/AllRecords")
	public List<Student> getAllRecords() {
		return studentService.getAllRecord();
	}

	@DeleteMapping("/Delete/{id}")
	public String deleteRecordById(@PathVariable int id) {
		studentService.deleteRecord(id);
		return "Record Deleted successfully";
	}

	@PutMapping("/update/{id}")
	public Student updateRecord(@RequestBody Student student, @PathVariable int id) {
		return studentService.updateRecord(student,id);
	}

}
